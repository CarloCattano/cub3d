compile with
make

avalilable:

 - make run - makes and runs

 - make debug - makes and runs in gdb
 
 - make mem - makes and runs in valgrind + help50

start game
```
./cub3d something_map.cub
```
