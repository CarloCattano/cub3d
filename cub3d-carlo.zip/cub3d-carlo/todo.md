### TO DO 

#### Map:
- enums for initial Direction:
	- NO SO WE EA F C
	- extraneous characters in map ?
- map validation
	- check for allowed chars:
	 ```0, 1 , D, space, initial_player_dir```

#### Minimap:
	- direction ray
	- FOV 

### Player:
	- initial dirX dirY = N | S | E | W

### Program flow:
- check config file
	- .cub extension
- readfile and check validity of data 
	- check texture path -> floor/ceiling color -> map
- parse map


### refactor
- draw function from tutorial into norminette friendly 

